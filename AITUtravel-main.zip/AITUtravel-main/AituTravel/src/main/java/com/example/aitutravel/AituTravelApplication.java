package com.example.aitutravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AituTravelApplication {

    public static void main(String[] args) {
        SpringApplication.run(AituTravelApplication.class, args);
    }

}
